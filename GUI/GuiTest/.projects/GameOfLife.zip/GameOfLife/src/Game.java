import java.awt.Color;
import java.util.Random;

public class Game {
	public Cell[][] data;
	public Game(Cell[][] data) {
		this.data = data;
	}
	public Cell getCell(int x, int y) {
		return data[x][y];
	}
	public Cell[][] getAllCells() {
		return data;
	}
	public void tick() {
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[0].length; j++) {
				data[i][j].calcNeighbors(data);
				if (data[i][j].getNeighbors() < 2) {
					data[i][j].setAliveNextTurn(false);
				}
				else if ((data[i][j].getNeighbors() == 3 || data[i][j].getNeighbors() == 2) && data[i][j].getAlive()) {
					data[i][j].setAliveNextTurn(true);
				}
				else if (data[i][j].getNeighbors() == 3 && !data[i][j].getAlive()) {
					data[i][j].setAliveNextTurn(true);
				}
				else if (data[i][j].getNeighbors() > 3) {
					data[i][j].setAliveNextTurn(false);
				}
			}
		}
	}
	public void setNextTurnState() {
		Random r = new Random();
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[0].length; j++) {
				final float hue = r.nextFloat();
				final float saturation = 0.9f;//1.0 for brilliant, 0.0 for dull
				final float luminance = 1.0f; //1.0 for brighter, 0.0 for black
				if (data[i][j].getAliveNextTurn()){
					data[i][j].setAlive(data[i][j].getAliveNextTurn(), Color.getHSBColor(hue, saturation, luminance));
				}
				else {
					data[i][j].setAlive(data[i][j].getAliveNextTurn());
				}
			}
		}
	}
}
